let currentImageIndex = 0;
let projectImages = [];
let projectData = []; 

// project deets / this yung nasa modals sa project sec  
const detailsLookup = {
    'Kwadro.jpg': {
        title: 'Kwadro Cafe Website',
        desc: 'A modern café website designed to showcase Kwadro Cafe’s brand, menu offerings, and services through a clean and user-friendly interface.',
        tech: 'HTML5, CSS3, JavaScript, Responsive Web Design, UI/UX Design Principles'
    },
    'YouMatter.png': {
        title: 'YouMatter Website',
        desc: 'A purpose-driven website created to promote mental wellness awareness and provide a safe digital space for users.',
        tech: 'HTML5, CSS3, JavaScript, Responsive Design, UI/UX Design'
    },
    'Kwadro MS.png': {
        title: 'Kwadro Cafe Management System',
        desc: 'A management system developed to streamline café operations including order handling and service organization.',
        tech: 'Java, OOP, Data Structures (Queues & Lists), File Handling, Console-Based Interface Design'
    },
    'voicebridge.jpg': {
        title: 'VoiceBridge – Working Prototype',
        desc: 'An assistive communication prototype designed to help bridge communication gaps using technology.',
        tech: 'Java / Android Development, UI Component Design, Event Handling, Prototype Development, Human-Centered Design'
    },
    'vaxicare1.png': {
        title: 'VaxiCare App',
        desc: 'A healthcare-focused mobile application concept designed to help users manage vaccination records and schedules.',
        tech: 'Android Studio, Java, Firebase, XML Layout Design, Mobile UI/UX Design'
    },
    'voicebridgeapp.jpg': {
        title: 'VoiceBridge App',
        desc: 'A mobile implementation of the VoiceBridge concept focused on accessible communication assistance.',
        tech: 'Android Studio, Java, XML UI Design, Event-Driven Programming, Accessibility-Focused Design'
    },
    'dearme1.png': {
        title: 'Dear Me',
        desc: 'A reflective digital concept project centered on emotional expression and self-reflection.',
        tech: 'UI/UX Design, Wireframing & Prototyping, Visual Design Principles'
    },
    'dearme2.png': { title: 'Dear Me (Internal View)', desc: 'Internal layout for the Dear Me project.', tech: 'UI/UX Design' },
    'gentlereads1.png': {
        title: 'Gentle Reads',
        desc: 'A book discovery and reading concept platform promoting relaxing and enjoyable reading experiences.',
        tech: 'UI/UX Design, Interface Prototyping, User Experience Planning'
    },
    'gentlereads2.png': { title: 'Gentle Reads (Library View)', desc: 'Visualizing the library interface.', tech: 'UI/UX Design' },
    'voicebridge2.png': {
        title: 'VoiceBridge (Concept Design)',
        desc: 'The conceptual foundation focusing on inclusive technology and communication accessibility.',
        tech: 'System Concept Design, UX Research, Wireframing, Interaction Design'
    },
    'jellycat.png': {
        title: 'Jellycat Branding',
        desc: 'A creative design project inspired by playful aesthetics, showcasing branding exploration.',
        tech: 'UI/UX Design, Visual Branding, Layout & Interface Design'
    }
};

// open modal 
function openPrototype(categoryTitle, imgArray) {
    const modal = document.getElementById('prototype-modal');
    const wrapper = document.getElementById('image-wrapper');
    projectImages = imgArray; 
    currentImageIndex = 0;
    wrapper.innerHTML = ''; 
    projectImages.forEach(src => {
        const img = document.createElement('img');
        img.src = src;
        wrapper.appendChild(img);
    });
    updateSlider();
    modal.classList.add('active');
    document.body.style.overflow = 'hidden';
}

function changeImage(step) {
    currentImageIndex += step;
    if (currentImageIndex >= projectImages.length) currentImageIndex = 0;
    if (currentImageIndex < 0) currentImageIndex = projectImages.length - 1;
    updateSlider();
}

function updateSlider() {
    const wrapper = document.getElementById('image-wrapper');
    if(!wrapper) return;
    wrapper.style.transform = `translateX(-${currentImageIndex * 100}%)`;
    const currentImgName = projectImages[currentImageIndex];
    const data = detailsLookup[currentImgName];
    if (data) {
        document.getElementById('modal-title').innerText = data.title;
        document.getElementById('modal-desc').innerHTML = `
            <div class="info-block"><h4>Description:</h4><p>${data.desc}</p></div>
            <div class="info-block"><h4>Technologies Used:</h4><p>${data.tech}</p></div>`;
    }
}

document.addEventListener('DOMContentLoaded', () => {
    const modal = document.getElementById('prototype-modal');
    const closeBtn = document.querySelector('.close-modal');
    if(closeBtn) closeBtn.onclick = () => { modal.classList.remove('active'); document.body.style.overflow = 'auto'; };
    
// initialize Map on load
    initLeafletMap();
});

//Calendar API
const API_KEY = "AIzaSyAUX_Bcs9a0YnROh3dkDQPfx3NEFekSOUI";
const MY_CALENDAR_ID = "dhanna.casungcad00321@gmail.com";

document.addEventListener('DOMContentLoaded', function() {
    var calendarEl = document.getElementById('calendar-viewer');
    var calendar = new FullCalendar.Calendar(calendarEl, {
        initialView: 'dayGridMonth',
        googleCalendarApiKey: API_KEY,
        events: { googleCalendarId: MY_CALENDAR_ID },
        headerToolbar: { left: 'prev,next', center: 'title', right: '' },
        height: 400,
        eventDisplay: 'block',
        eventBackgroundColor: '#ff9d00',
        eventBorderColor: '#ff9d00',
        eventClick: function(info) {
            info.jsEvent.preventDefault();
            alert("Already Booked: " + info.event.title);
        }
    });
    calendar.render();
});

// EmailJS API - appointment booking
emailjs.init("wZrQ9rwzk_kw6qhFK");
document.getElementById('appointment-form').onsubmit = function(e) {
    e.preventDefault();
    const btn = document.getElementById('app-submit-btn');
    btn.innerText = "Sending...";
    const templateParams = {
        from_name: document.getElementById('app_name').value,
        reply_to: document.getElementById('app_email').value,
        booking_date: document.getElementById('app_date').value,
        service: document.getElementById('app_type').value,
        message: `Booking request for ${document.getElementById('app_type').value} on ${document.getElementById('app_date').value}`
    };
    emailjs.send('service_23ljp7m', 'template_1mvprlm', templateParams)
        .then(() => {
            alert(`Thanks ${templateParams.from_name}! Booking sent.`);
            this.reset();
            btn.innerText = "Confirm Booking Request";
        }, (error) => {
            alert("Booking Error: " + JSON.stringify(error));
            btn.innerText = "Confirm Booking Request";
        });
};
// EmailJS API - inquiry form
document.getElementById('email-form').onsubmit = function(e) {
    e.preventDefault();
    const btn = document.getElementById('msg-submit-btn');
    btn.innerText = "Sending Message...";
    emailjs.sendForm('service_23ljp7m', 'template_1mvprlm', this)
        .then(() => {
            alert("Message Sent successfully!");
            this.reset();
            btn.innerText = "Send Message";
        }, (error) => {
            alert("Failed to send message...");
            btn.innerText = "Send Message";
        });
};

//Maps API
function initLeafletMap() {
    const lat = 14.109034727827469; 
    const lng = 122.95630549961497;
    const apiKey = "c0a53418af3c4052bc6129155aac40b2"; 
    const map = L.map('map').setView([lat, lng], 17);
    const isRetina = L.Browser.retina;
    const baseUrl = `https://maps.geoapify.com/v1/tile/osm-bright/{z}/{x}/{y}.png?apiKey=${apiKey}`;
    const retinaUrl = `https://maps.geoapify.com/v1/tile/osm-bright/{z}/{x}/{y}@2x.png?apiKey=${apiKey}`;
    L.tileLayer(isRetina ? retinaUrl : baseUrl, {
        attribution: 'Powered by <a href="https://www.geoapify.com/" target="_blank">Geoapify</a>',
        maxZoom: 20,
    }).addTo(map);
    L.marker([lat, lng]).addTo(map).bindPopup("<b>CNSC Main Campus</b>").openPopup();
}